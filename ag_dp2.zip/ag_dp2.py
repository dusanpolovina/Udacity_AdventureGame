def print_pause(words):
    import time
    print(words)
    time.sleep(2)


def intro(villain_choice):
    print_pause("You find yourself standing in an open field,"
                " filled with grass and yellow wildflowers.")
    print_pause(f"Rumor has it that a {villain_choice} is somewhere"
                " around here, and has been terrifying the nearby village.")
    print_pause("In front of you is a HOUSE")
    print_pause("To the right of you is a dark CAVE")
    print_pause("In your hand you hold your trusty"
                " (but not very effective) DAGGER")


def open_field(items, villain_choice):
    print_pause("Enter 1 to knock on the door of the HOUSE")
    print_pause("Enter 2 to peer into the CAVE")
    print_pause("What would you like to do?")
    choice1 = input("(Please enter 1 or 2).\n").lower()
    if "1" in choice1 or "door" in choice1 or "house" in choice1:
        house(items, villain_choice)
    elif "2" in choice1 or "peer" in choice1 or "cave" in choice1:
        cave(items, villain_choice)
    else:
        print_pause("I'm sorry I don't understand.")
        open_field(items, villain_choice)


def house(items, villain_choice):
    print_pause("You approach the door of the HOUSE")
    print_pause("You are about to knock when the "
                f"door opens and out steps a {villain_choice}")
    print_pause(f"Eeep! This is the {villain_choice}'s house")
    print_pause(f"The {villain_choice} attacks you!")
    if "sword of ogoroth" not in items and "dagger" in items:
        print_pause("You feel a little under-prepared "
                    "with just your tiny DAGGER")
        choice2 = input("Would you like to FIGHT(1) or RUN AWAY(2)\n").lower()
        if "1" in choice2 or "fight" in choice2:
            print_pause(f"The {villain_choice} kills you Whomp whomp")
            play_again()
        elif "2" in choice2 or "run" in choice2 or "away" in choice2:
            print_pause("You run back out to the field")
            open_field(items, villain_choice)
    elif "sword of ogoroth" in items:
        print_pause("You feel very confident with your new SWORD")
        choice3 = input("Would you like to FIGHT(1) or RUN AWAY(2)\n").lower()
        if "1" in choice3 or "fight" in choice3:
            win(villain_choice)
            # break
        elif "2" in choice3 or "run" in choice3 or "away" in choice3:
            print_pause("You run back out to the field")
            open_field(items, villain_choice)


def cave(items, villain_choice):
    if "sword of ogoroth" not in items:
        print_pause("You peer cautiously into the CAVE")
        print_pause("It turns out to only be a very small CAVE")
        print_pause("Your eye catches a glint of metal behind a rock")
        print_pause("You have found the magical SWORD of OGOROTH")
        print_pause("You discard your silly old DAGGER "
                    "and take the SWORD with you")
        items.append("sword of ogoroth")
        items.remove("dagger")
        print_pause("You walk back out to the open field")
        open_field(items, villain_choice)
    elif "sword of ogoroth" in items:
        print_pause("You peer into the cave again, "
                    "seeing only your old dagger on the ground")
        print_pause("You walk back out to the open field")
        open_field(items, villain_choice)


def win(villain_choice):
    print_pause(f"As the {villain_choice} moves to attack you,"
                " you unsheath the SWORD OF OGOROTH")
    print_pause("The sword shimmers brightly in your "
                "hand as you brace for the attack")
    print_pause(f"But the {villain_choice} sees "
                "the SWORD OF OGOROTH and flees!")
    print_pause(f"You have rid the village of the "
                f"evil {villain_choice}, you are victorious!")
    play_again()


def lose():
    print_pause("The dragon kills you Whomp whomp")
    play_again()


def play_again():
    choice_again = input("Would you like to play again? (y/n)").lower()
    if "y" in choice_again or "yes" in choice_again:
        print_pause("Great, let's adventure again!")
        play_game()
    elif "n" in choice_again or "no" in choice_again:
        print_pause("OK, let's play again sometime")
        # break
    else:
        print_pause("Sorry, I don't understand, please respond y/n")
        play_again()


def select_villain():
    import random
    villains = ["DRAGON", "WICKED FAERIE", "UGLY TROLL",
                "MINOTAUR", "CHUPACABRA", "VAMPIRE", "GOBLIN"]
    # global villain_choice
    villain_choice = random.choice(villains)
    return villain_choice


def play_game():
    villain_choice = select_villain()
    items = []
    items.append("dagger")
    intro(villain_choice)
    open_field(items, villain_choice)


play_game()
